import { NgModule } from '@angular/core';
import { CanvasDrawComponent } from './canvas-draw/canvas-draw';
@NgModule({
	declarations: [CanvasDrawComponent],
	imports: [],
	exports: [CanvasDrawComponent]
})
export class ComponentsModule {}
