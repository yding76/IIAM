import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TrachPage } from './trach';

@NgModule({
  declarations: [
    TrachPage,
  ],
  imports: [
    IonicPageModule.forChild(TrachPage),
  ],
})
export class TrachPageModule {}
