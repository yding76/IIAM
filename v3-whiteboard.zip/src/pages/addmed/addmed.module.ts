import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddmedPage } from './addmed';

@NgModule({
  declarations: [
    AddmedPage,
  ],
  imports: [
    IonicPageModule.forChild(AddmedPage),
  ],
})
export class AddmedPageModule {}
